import React from 'react';

const Logo = () => (
  <h1 className="text-4xl text-red-600 font-heading tracking-wide uppercase">
  PIIcasso
  </h1>
);

export default Logo;
